import React , {useState} from 'react'

export default function StartPage() {



    
  return (
    <div>
      <center>
      <h1>Welcome To Guess The Number Game</h1>
      <h2>Press Start To Enter In Game</h2>


      </center>
    </div>
  )
}

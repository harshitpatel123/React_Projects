"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var react_1 = require("react");
function StartPage() {
    return (<div>
      <center>
      <h1>Welcome To Guess The Number Game</h1>
      <h2>Press Start To Enter In Game</h2>


      </center>
    </div>);
}
export default StartPage;

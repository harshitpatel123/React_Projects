import React from 'react'

export default function StartPage() {
  return (
    <div>
      <center>
        <h1>Welcome to Daily Quiz</h1>
        <br />
      </center>
        <p>Instructions : <br />
        (1) There are 10 questions in the test. <br />
        (2) All Questions contain 1 point weightage.    <br />
        (3) Result will be declared at the end of the quiz. <br />
        <br />
        </p>
        <center>
        <h2>Press Start to check your general knowledge</h2>
        <br /><br />
        </center>
    </div>
  )
}

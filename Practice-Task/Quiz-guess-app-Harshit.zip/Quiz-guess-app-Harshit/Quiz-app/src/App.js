import logo from './logo.svg';
import './App.css';
import Quiz from './component/Quiz';


function App() {
  return (
    <div className='centerdiv'>
      <Quiz />
    </div>
  );
}

export default App;
